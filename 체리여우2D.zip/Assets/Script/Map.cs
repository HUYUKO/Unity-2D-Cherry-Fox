﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Map : MonoBehaviour
{
    private Player player_move;

    private void Awake()
    {

    }

    void Start()
    {
        player_move = FindObjectOfType<Player>();
    }


    // Update is called once per frame
    void Update()
    {


    }

    // 문에 플레이어가 닿을시 다음 스테이지로 이동
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "player")
        {
            Destroy(other.gameObject);
            SceneManager.LoadScene("level1");
        }

        if (other.gameObject.tag == "door1")
        {
            Destroy(other.gameObject);
            SceneManager.LoadScene("level2");
        }
    }



}
