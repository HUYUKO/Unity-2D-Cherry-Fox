﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    UnityEngine.UI.Text Cherry;

    GameObject Camera;
    GameObject player;
    GameObject Back;

    Rigidbody2D rigid;
    Animator animator; // 애니메이터 변경


    // 캐릭터 이동 힘
    public float jum_power = 8f;
    float movePower = 3;
    float startTime = 0;

    // 수평이동 차단, 수직이동 여부
    private bool m_ladder, m_air;

    bool isDie = false; // 죽음 여부
    int health = 3;
    public int maxHealth = 3; // 주요 스탯

    // Start is called before the first frame update
    void Start()
    {
        Cherry = GameObject.Find("cherryScore").GetComponent<UnityEngine.UI.Text>();
        animator = gameObject.GetComponentInChildren<Animator>();

        m_ladder = false; m_air = false;

        health = maxHealth;

        startTime = Time.time;

        // 카메라
        Camera = GameObject.Find("Main Camera");
        player = GameObject.Find("player");

    }

    // Update is called once per frame
    void Update()
    {
        Camera.transform.position = new Vector3(player.transform.position.x, player.transform.position.y, -10);
        keyAction();
    }



    // 캐릭터 이동
    void keyAction()
    {
        Vector3 moveVelocity = Vector3.zero;
        if (Input.GetAxisRaw("Horizontal") < 0)
        {
            moveVelocity = Vector3.left;
            transform.rotation = Quaternion.Euler(0, 180, 0);
        }
        else if (Input.GetAxisRaw("Horizontal") > 0)
        {
            moveVelocity = Vector3.right;
            transform.rotation = Quaternion.Euler(0, 0, 0);
        }
        transform.position += moveVelocity * movePower * Time.deltaTime;

        jump();
    }

    // 캐릭터 점프
    void jump()
    {
        if (Input.GetKeyDown(KeyCode.Space))
            this.GetComponent<Rigidbody2D>().AddForce(this.transform.up * 7, ForceMode2D.Impulse);
    }

    // 체리 충돌판정
    private void OnTriggerEnter2D(Collider2D other)
    {
        // 체리 충돌시 사라지면서 스코어 증가
        if (other.gameObject.tag == "cherry")
        {
            other.gameObject.SetActive(false);
            FindObjectOfType<Score>().AddPoint();
        }
    }

}
