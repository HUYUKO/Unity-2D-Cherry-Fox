﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Background : MonoBehaviour
{
    public float scrollSpeed = 0.1f;
    public float scrollSize = 0.5f;

    // Start is called before the first frame update
    void Start()
    {
        float x = Mathf.Repeat(Time.time * scrollSpeed, scrollSize);
        Vector2 offset = new Vector2(x, 0);
        GetComponent<Renderer>().materials[0].SetTextureOffset("_MainTex", offset);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
