﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    int score = 0; // 점수저장 변수
    Text text_score;

    private void Awake()
    {
        text_score = GetComponent<Text>();
    }

    public void AddPoint()
    {
        score += 1;
        UpdateTextUi();
    }

    public void UpdateTextUi()
    {
        text_score.text = "x " + score.ToString();
    }

    public int GetScore()
    {
        return score;
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    }

}
